---
title: Small text
---
This is an example of a blog post with small amount of text.